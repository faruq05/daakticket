# CHANGELOG

## V 3.0.1
- bugfixes

## V 3.0.0
- Bootstrap5


## V 2.0.0
- Added more layouts
- Design improvements
- Bug fixes
- Better changes for file structure

## V 1.0.0
- Initial release
